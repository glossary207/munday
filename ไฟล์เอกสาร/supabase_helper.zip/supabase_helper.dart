import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:supabase_flutter/supabase_flutter.dart';
import 'supabase_config.dart';

/// Helper class for Supabase database operations
class SupabaseHelper {
  static SupabaseClient get _client => supabase;
  static SupabaseClient get client => supabase; // public accessor สำหรับ widget ที่ต้องการใช้ channel โดยตรง

  // ========================================
  // READ Operations
  // ========================================

  static Future<Map<String, dynamic>?> getDocBy(
  String table,
  Map<String, Object> equals,
) async {
  try {
    final response = await _client
        .from(table)
        .select()
        .match(equals) // หรือจะใช้ chain .eq() ก็ได้
        .maybeSingle();
    return response;
  } catch (e) {
    print('Error getting document from $table: $e');
    rethrow;
  }
}


  /// Get a single document by ID
  static Future<Map<String, dynamic>?> getDoc(
    String table,
    String id,
  ) async {
    try {
      final response =
          await _client.from(table).select().eq('id', id).maybeSingle();
      return response;
    } catch (e) {
      print('Error getting document from $table: $e');
      rethrow;
    }
  }

  /// Get multiple documents
  static Future<List<Map<String, dynamic>>> getDocs(
    String table, {
    String? orderBy,
    bool ascending = true,
    int? limit,
    Map<String, dynamic>? filters,
  }) async {
    try {
      dynamic query = _client.from(table).select();

      // Apply filters
      if (filters != null) {
        filters.forEach((key, value) {
          query = query.eq(key, value);
        });
      }

      // Apply ordering (.order() คืน PostgrestTransformBuilder ไม่ใช่ PostgrestFilterBuilder)
      if (orderBy != null) {
        query = query.order(orderBy, ascending: ascending);
      }

      // Apply limit
      if (limit != null) {
        query = query.limit(limit);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error getting documents from $table: $e');
      rethrow;
    }
  }

  /// Query with complex filters
  static Future<List<Map<String, dynamic>>> query(
    String table, {
    Map<String, dynamic>? equals,
    Map<String, dynamic>? notEquals,
    Map<String, List<dynamic>>? inList,
    Map<String, List<dynamic>>? notInList,
    Map<String, dynamic>? greaterThan,
    Map<String, dynamic>? lessThan,
    String? orderBy,
    bool ascending = true,
    int? limit,
  }) async {
    try {
      dynamic query = _client.from(table).select();

      // Apply equals filters
      if (equals != null) {
        equals.forEach((key, value) {
          query = query.eq(key, value);
        });
      }

      // Apply not equals filters
      if (notEquals != null) {
        notEquals.forEach((key, value) {
          query = query.neq(key, value);
        });
      }

      // Apply in filters
      if (inList != null) {
        inList.forEach((key, value) {
          query = query.inFilter(key, value);
        });
      }

      // Apply not in filters
      if (notInList != null) {
        notInList.forEach((key, value) {
          query = query.not(key, 'in', value);
        });
      }

      // Apply greater than filters
      if (greaterThan != null) {
        greaterThan.forEach((key, value) {
          query = query.gt(key, value);
        });
      }

      // Apply less than filters
      if (lessThan != null) {
        lessThan.forEach((key, value) {
          query = query.lt(key, value);
        });
      }

      // Apply ordering
      if (orderBy != null) {
        query = query.order(orderBy, ascending: ascending);
      }

      // Apply limit
      if (limit != null) {
        query = query.limit(limit);
      }

      final response = await query;
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error querying $table: $e');
      rethrow;
    }
  }

  // ========================================
  // TRANSACTION-like API (run multiple ops; for real atomicity use RPC)
  // ========================================

  /// Runs a "transaction" callback with a [SupabaseTransaction] that supports
  /// get/set/update/delete. Each operation is a separate HTTP request.
  /// For true ACID transactions, put logic in a PostgreSQL function and call
  /// [SupabaseHelper.rpc] instead.
  static Future<T> runTransaction<T>(
    Future<T> Function(SupabaseTransaction transaction) fn,
  ) async {
    final tx = SupabaseTransaction(_client);
    return fn(tx);
  }

  // ========================================
  // WRITE Operations
  // ========================================

  /// Create a new document
  static Future<Map<String, dynamic>> addDoc(
    String table,
    Map<String, dynamic> data,
  ) async {
    try {
      final response = await _client.from(table).insert(data).select().single();
      return response;
    } catch (e) {
      print('Error adding document to $table: $e');
      rethrow;
    }
  }

  /// Create multiple documents
  static Future<List<Map<String, dynamic>>> addDocs(
    String table,
    List<Map<String, dynamic>> dataList,
  ) async {
    try {
      final response = await _client.from(table).insert(dataList).select();
      return List<Map<String, dynamic>>.from(response);
    } catch (e) {
      print('Error adding documents to $table: $e');
      rethrow;
    }
  }

  /// Update a document
  static Future<void> updateDoc(
    String table,
    String id,
    Map<String, dynamic> data,
  ) async {
    try {
      await _client.from(table).update(data).eq('id', id);
    } catch (e) {
      print('Error updating document in $table: $e');
      rethrow;
    }
  }

  /// Update document(s) by composite key (e.g. venue_id + date)
  static Future<void> updateDocBy(
    String table,
    Map<String, dynamic> equals,
    Map<String, dynamic> data,
  ) async {
    try {
      var q = _client.from(table).update(data);
      equals.forEach((key, value) {
        q = q.eq(key, value);
      });
      await q;
    } catch (e) {
      print('Error updating document in $table by $equals: $e');
      rethrow;
    }
  }

  /// Upsert (insert or update) a document
  static Future<Map<String, dynamic>> upsertDoc(
    String table,
    Map<String, dynamic> data,
  ) async {
    try {
      final response = await _client.from(table).upsert(data).select().single();
      return response;
    } catch (e) {
      print('Error upserting document in $table: $e');
      rethrow;
    }
  }

  /// Delete a document
  static Future<void> deleteDoc(
    String table,
    String id,
  ) async {
    try {
      await _client.from(table).delete().eq('id', id);
    } catch (e) {
      print('Error deleting document from $table: $e');
      rethrow;
    }
  }

  // ========================================
  // REAL-TIME Subscriptions
  // ========================================

  /// Subscribe to all changes in a collection
  static Stream<List<Map<String, dynamic>>> subscribeToCollection(
    String table, {
    Map<String, dynamic>? filters,
    String? orderBy,
    bool ascending = true,
  }) {
    try {
      var stream = _client.from(table).stream(primaryKey: ['id']);

      // Apply filters
      if (filters != null) {
        filters.forEach((key, value) {
          stream = stream.eq(key, value) as SupabaseStreamFilterBuilder;
        });
      }

      // Apply ordering
      if (orderBy != null) {
        stream = stream.order(orderBy, ascending: ascending)
            as SupabaseStreamFilterBuilder;
      }

      return stream;
    } catch (e) {
      print('Error subscribing to $table: $e');
      rethrow;
    }
  }

  /// Subscribe to a single document
  static Stream<Map<String, dynamic>?> subscribeToDocument(
    String table,
    String id,
  ) {
    try {
      return _client
          .from(table)
          .stream(primaryKey: ['id'])
          .eq('id', id)
          .map((list) => list.isEmpty ? null : list.first);
    } catch (e) {
      print('Error subscribing to document in $table: $e');
      rethrow;
    }
  }

  // ========================================
  // STORAGE Operations
  // ========================================

  /// Upload a file to storage (public bucket - returns public URL)
  static Future<String> uploadFile(
    String bucket,
    String path,
    Uint8List fileBytes, {
    String? contentType,
    bool upsert = false,
  }) async {
    try {
      await _client.storage.from(bucket).uploadBinary(
            path,
            fileBytes,
            fileOptions: FileOptions(
              contentType: contentType ?? 'application/octet-stream',
              upsert: upsert,
            ),
          );
      return _client.storage.from(bucket).getPublicUrl(path);
    } catch (e) {
      print('Error uploading file to $bucket/$path: $e');
      rethrow;
    }
  }

  /// Upload a file to private storage (returns signed URL)
  static Future<String> uploadFilePrivate(
    String bucket,
    String path,
    Uint8List fileBytes, {
    String? contentType,
    bool upsert = false,
    int expiresIn = 3600, // 1 hour default
  }) async {
    try {
      await _client.storage.from(bucket).uploadBinary(
            path,
            fileBytes,
            fileOptions: FileOptions(
              contentType: contentType ?? 'application/octet-stream',
              upsert: upsert,
            ),
          );
      // Get signed URL for private bucket
      return await _client.storage
          .from(bucket)
          .createSignedUrl(path, expiresIn);
    } catch (e) {
      print('Error uploading file to private bucket $bucket/$path: $e');
      rethrow;
    }
  }

  /// Get public URL for a file
  static String getFileUrl(String bucket, String path) {
    return _client.storage.from(bucket).getPublicUrl(path);
  }

  /// Get signed URL for a private file (valid for 1 hour)
  static Future<String> getSignedUrl(
    String bucket,
    String path, {
    int expiresIn = 3600, // 1 hour default
  }) async {
    try {
      final response =
          await _client.storage.from(bucket).createSignedUrl(path, expiresIn);
      return response;
    } catch (e) {
      print('Error getting signed URL for $bucket/$path: $e');
      rethrow;
    }
  }

  /// Delete a file from storage
  static Future<void> deleteFile(String bucket, String path) async {
    try {
      await _client.storage.from(bucket).remove([path]);
    } catch (e) {
      print('Error deleting file from $bucket/$path: $e');
      rethrow;
    }
  }

  // ========================================
  // UTILITY Functions
  // ========================================

  /// Count documents in a table
  static Future<int> count(
    String table, {
    Map<String, dynamic>? filters,
  }) async {
    try {
      var query = _client.from(table).select('id');

      // Apply filters
      if (filters != null) {
        filters.forEach((key, value) {
          query = query.eq(key, value);
        });
      }

      final data = await query;
      return data.length;
    } catch (e) {
      print('Error counting documents in $table: $e');
      rethrow;
    }
  }

  /// Execute a stored procedure (RPC)
  static Future<dynamic> rpc(
    String functionName,
    Map<String, dynamic>? params,
  ) async {
    try {
      return await _client.rpc(functionName, params: params);
    } catch (e) {
      print('Error calling RPC $functionName: $e');
      rethrow;
    }
  }

  /// Fetch layout from normalized tables (venue_daily_layout_floors, venue_daily_layout_tables)
  /// and build the same structure as old venue_daily_layouts.floors
  static Future<Map<String, dynamic>?> fetchLayoutFromNormalizedTables(
    String venueId,
    String date,
  ) async {
    try {
      final layoutRows = await _client
          .from('venue_daily_layouts')
          .select()
          .eq('venue_id', venueId)
          .eq('date', date)
          .limit(1);
      if (layoutRows.isEmpty) return null;
      final layout = Map<String, dynamic>.from(layoutRows.first);

      final floorRows = await _client
          .from('venue_daily_layout_floors')
          .select()
          .eq('venue_daily_layout_id', layout['id'])
          .order('sort_order', ascending: true);
      if (floorRows.isEmpty) return null;

      final Map<String, dynamic> floors = {};
      for (final f in floorRows) {
        final floorId = f['id'] as String?;
        final floorKey = (f['floor_key'] ?? '').toString();
        if (floorKey.isEmpty || floorId == null) continue;

        final tableRows = await _client
            .from('venue_daily_layout_tables')
            .select()
            .eq('venue_daily_layout_floor_id', floorId)
            .order('table_key', ascending: true);

        final Map<String, dynamic> tableLayout = {};
        for (final t in tableRows) {
          final tk = (t['table_key'] ?? '').toString();
          if (tk.isEmpty) continue;
          final xi = t['xi'] as List?;
          final yi = t['yi'] as List?;
          final status = {
            'status_code': t['status_code'] ?? 'available',
            'customer_uid': (t['customer_uid'] ?? '').toString(),
            'staff_bill_id': (t['staff_bill_id'] ?? '').toString(),
            'status_action_timestamp': t['status_action_timestamp'],
          };
          final extra = t['status_extra'] as Map?;
          if (extra != null) {
            for (final e in extra.entries) {
              status[e.key.toString()] = e.value;
            }
          }
          tableLayout[tk] = {
            'xi': xi ?? [0, 100],
            'yi': yi ?? [0, 100],
            'type': t['shape_type'] ?? 'table',
            'status': status,
            'table_name': t['display_name'] ?? tk,
            if (t['min_capacity'] != null) 'min_seat': t['min_capacity'],
            if (t['max_capacity'] != null) 'max_seat': t['max_capacity'],
            ...Map<String, dynamic>.from(t['meta'] as Map? ?? {}),
          };
        }
        floors[floorKey] = {
          'table_layout': tableLayout,
          if (f['walls'] != null) 'walls': f['walls'],
          if (f['bounds'] != null) 'bounds': f['bounds'],
        };
      }
      layout['floors'] = floors;
      layout['table_layout'] = null;
      return layout;
    } catch (e) {
      print('Error fetchLayoutFromNormalizedTables: $e');
      return null;
    }
  }

  /// Check if layout uses normalized tables (has rows in venue_daily_layout_floors)
  static Future<bool> layoutUsesNormalized(String venueId, String date) async {
    try {
      final layoutRows = await _client
          .from('venue_daily_layouts')
          .select('id')
          .eq('venue_id', venueId)
          .eq('date', date)
          .limit(1);
      if (layoutRows.isEmpty) return false;
      final layoutId = layoutRows.first['id'];
      final floorRows = await _client
          .from('venue_daily_layout_floors')
          .select('id')
          .eq('venue_daily_layout_id', layoutId)
          .limit(1);
      return floorRows.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  /// ดึง layout ปัจจุบันครั้งเดียว
  /// ใช้ normalized tables ก่อน (schema ใหม่), fallback legacy table_layout
  static Future<Map<String, dynamic>?> fetchVenueDailyLayoutOnce(
    String venueId,
    String date,
  ) async {
    try {
      final usesNormalized = await layoutUsesNormalized(venueId, date);
      if (usesNormalized) {
        print('📦 fetchVenueDailyLayoutOnce: using normalized tables');
        return await fetchLayoutFromNormalizedTables(venueId, date);
      }

      // legacy: ดึงจาก venue_daily_layouts โดยตรง (floors JSONB หรือ table_layout)
      final rows = await _client
          .from('venue_daily_layouts')
          .select()
          .eq('venue_id', venueId)
          .eq('date', date)
          .limit(1);
      if (rows.isEmpty) return null;
      print('📦 fetchVenueDailyLayoutOnce: using legacy');
      return Map<String, dynamic>.from(rows.first);
    } catch (e) {
      print('Error fetchVenueDailyLayoutOnce: $e');
      return null;
    }
  }

  /// Update table status in normalized layout for given table ids
  static Future<void> updateNormalizedTablesStatus(
    String venueId,
    String date,
    String floorKey,
    List<String> tableKeys,
    Map<String, dynamic> statusMap,
  ) async {
    if (tableKeys.isEmpty) return;
    try {
      final layoutRows = await _client
          .from('venue_daily_layouts')
          .select('id')
          .eq('venue_id', venueId)
          .eq('date', date)
          .limit(1);
      if (layoutRows.isEmpty) throw Exception('Layout not found');
      final layoutId = layoutRows.first['id'];

      final floorRows = await _client
          .from('venue_daily_layout_floors')
          .select('id')
          .eq('venue_daily_layout_id', layoutId)
          .eq('floor_key', floorKey)
          .limit(1);
      if (floorRows.isEmpty) throw Exception('Floor not found');
      final floorId = floorRows.first['id'];

      final sb = statusMap['staff_bill_id']?.toString() ?? '';
      print('sb: $sb');
      final updateData = <String, dynamic>{
        'status_code': statusMap['status_code'] ?? 'available',
        'customer_uid': (statusMap['customer_uid'] ?? '').toString(),
        'staff_bill_id': sb.isEmpty ? null : sb,
        'status_action_timestamp': statusMap['status_action_timestamp'],
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      };
      for (final tk in tableKeys) {
        final rows = await _client
            .from('venue_daily_layout_tables')
            .select('id')
            .eq('venue_daily_layout_floor_id', floorId)
            .eq('table_key', tk);
        for (final r in rows) {
          final rowId = r['id'] as String;
          print('🔵 [updateNormalized] updating row $rowId with $updateData');
          final result = await _client
              .from('venue_daily_layout_tables')
              .update(updateData)
              .eq('id', rowId)
              .select('id, status_code, staff_bill_id');
          print('🟢 [updateNormalized] after update: $result');
        }
      }
    } catch (e) {
      print('Error updateNormalizedTablesStatus: $e');
      rethrow;
    }
  }

  /// Subscribe to venue_daily_layouts by venue_id and date
  /// Supports both: (1) normalized tables (venue_daily_layout_floors, venue_daily_layout_tables)
  /// and (2) legacy JSONB (floors/table_layout in venue_daily_layouts)
  static Stream<Map<String, dynamic>?> subscribeToVenueDailyLayout(
    String venueId,
    String date, // YYYY-MM-DD format
  ) {
    return Stream.multi((controller) async {
      // ใช้ explicit Supabase channel — client ถือ reference ไว้เอง ไม่หลุดจาก GC
      RealtimeChannel? channel;
      bool active = true;

      controller.onCancel = () {
        active = false;
        if (channel != null) {
          _client.removeChannel(channel!);
          channel = null;
          print('🔔 [subscribeToVenueDailyLayout] channel removed (onCancel)');
        }
      };

      void safeAdd(Map<String, dynamic>? data) {
        if (!active) return;
        try { controller.add(data); } catch (_) {}
      }

      try {
        print('🔔 [subscribeToVenueDailyLayout] START venue=$venueId date=$date');
        final usesNormalized = await layoutUsesNormalized(venueId, date);
        if (!active) return;
        print('🔔 [subscribeToVenueDailyLayout] usesNormalized=$usesNormalized');

        // Initial data emit
        final initial = usesNormalized
            ? await fetchLayoutFromNormalizedTables(venueId, date)
            : await _fetchLegacyLayout(venueId, date);
        if (!active) return;
        safeAdd(initial);

        // ตาราง Realtime ที่จะ subscribe
        final tableName = usesNormalized
            ? 'venue_daily_layout_tables'
            : 'venue_daily_layouts';

        // สร้าง channel ที่ unique ต่อ venue+date
        final channelId = 'layout-$venueId-$date';
        channel = _client
            .channel(channelId)
            .onPostgresChanges(
              event: PostgresChangeEvent.all,
              schema: 'public',
              table: tableName,
              callback: (PostgresChangePayload payload) async {
                if (!active) return;
                print('🔔 [Realtime] $tableName CHANGED (${payload.eventType}) → refetching');
                final updated = usesNormalized
                    ? await fetchLayoutFromNormalizedTables(venueId, date)
                    : await _fetchLegacyLayout(venueId, date);
                if (!active) return;
                safeAdd(updated);
              },
            )
            .subscribe((RealtimeSubscribeStatus status, [Object? error]) {
              print('🔔 [Realtime] channel "$channelId" status: $status${error != null ? ' error: $error' : ''}');
            });

        // race condition: ถ้า cancel มาก่อน channel ถูก assign
        if (!active) {
          _client.removeChannel(channel!);
          channel = null;
          return;
        }

        print('🔔 [subscribeToVenueDailyLayout] channel subscribed ✅ table=$tableName');
      } catch (e) {
        print('🔴 Error in subscribeToVenueDailyLayout: $e');
        if (!active) return;
        try { controller.addError(e); } catch (_) {}
      }
    });
  }

  /// ดึง layout legacy (JSONB floors/table_layout ใน venue_daily_layouts)
  static Future<Map<String, dynamic>?> _fetchLegacyLayout(
      String venueId, String date) async {
    final rows = await _client
        .from('venue_daily_layouts')
        .select()
        .eq('venue_id', venueId)
        .eq('date', date)
        .limit(1);
    return rows.isEmpty ? null : Map<String, dynamic>.from(rows.first);
  }

  /// Save floors JSON to normalized tables (venue_daily_layouts, venue_daily_layout_floors, venue_daily_layout_tables)
  /// [floors] format: { floorKey: { table_layout: {...}, walls?: {...} } }
  static Future<void> saveFloorsToNormalizedTables(
    String venueId,
    String date,
    Map<String, dynamic> floors,
  ) async {
    if (floors.isEmpty) return;
    final layoutRows = await _client
        .from('venue_daily_layouts')
        .select('id')
        .eq('venue_id', venueId)
        .eq('date', date)
        .limit(1);
    String layoutId;
    if (layoutRows.isEmpty) {
      final inserted = await _client
          .from('venue_daily_layouts')
          .insert({
            'venue_id': venueId,
            'date': date,
          })
          .select('id')
          .single();
      layoutId = inserted['id'] as String;
    } else {
      layoutId = layoutRows.first['id'] as String;
    }

    final floorRows = await _client
        .from('venue_daily_layout_floors')
        .select('id')
        .eq('venue_daily_layout_id', layoutId);
    for (final f in floorRows) {
      await _client
          .from('venue_daily_layout_tables')
          .delete()
          .eq('venue_daily_layout_floor_id', f['id']);
      await _client
          .from('venue_daily_layout_floors')
          .delete()
          .eq('id', f['id']);
    }

    final floorKeys = (floors.keys.toList()..sort());
    for (int si = 0; si < floorKeys.length; si++) {
      final floorKey = floorKeys[si];
      final fdata = Map<String, dynamic>.from(floors[floorKey] ?? {});
      final tableLayout = Map<String, dynamic>.from(fdata['table_layout'] ?? {});
      final walls = fdata['walls'];
      final bounds = fdata['bounds'];

      final floorInserted = await _client
          .from('venue_daily_layout_floors')
          .insert({
            'venue_daily_layout_id': layoutId,
            'floor_key': floorKey,
            'sort_order': si,
            if (walls != null) 'walls': walls,
            if (bounds != null) 'bounds': bounds,
          })
          .select('id')
          .single();
      final floorId = floorInserted['id'] as String;

      final tableKeys = tableLayout.keys.toList()..sort();
      for (final tk in tableKeys) {
        final t = Map<String, dynamic>.from(tableLayout[tk] ?? {});
        final xi = t['xi'] as List<dynamic>? ?? [0.0, 100.0];
        final yi = t['yi'] as List<dynamic>? ?? [0.0, 100.0];
        final status = Map<String, dynamic>.from(t['status'] ?? {});
        final meta = <String, dynamic>{};
        for (final k in ['color', 'table_name', 'price', 'min_seat', 'max_seat', 'user_data']) {
          if (t.containsKey(k)) meta[k] = t[k];
        }
        final displayName = (t['table_name'] ?? tk).toString();
        final minCap = t['min_seat'] ?? t['min_capacity'];
        final maxCap = t['max_seat'] ?? t['max_capacity'];

        await _client.from('venue_daily_layout_tables').insert({
          'venue_daily_layout_floor_id': floorId,
          'table_key': tk.toString(),
          'xi': xi,
          'yi': yi,
          'shape_type': t['type'] ?? 'table',
          'status_code': status['status_code'] ?? 'available',
          'customer_uid': status['customer_uid']?.toString() ?? '',
          'staff_bill_id': status['staff_bill_id']?.toString(),
          'status_action_timestamp': status['status_action_timestamp'],
          'display_name': displayName,
          if (minCap != null) 'min_capacity': minCap,
          if (maxCap != null) 'max_capacity': maxCap,
          if (meta.isNotEmpty) 'meta': meta,
        });
      }
    }
  }

  /// Fetch preset layouts for venue (preset_layouts where venue_id = X)
  static Future<List<Map<String, dynamic>>> fetchPresetLayouts(String venueId) async {
    try {
      final rows = await _client
          .from('preset_layouts')
          .select()
          .eq('venue_id', venueId)
          .order('created_time', ascending: false);
      return List<Map<String, dynamic>>.from(rows);
    } catch (e) {
      print('Error fetchPresetLayouts: $e');
      return [];
    }
  }

  /// Get layout_data (floors) from preset_layouts
  /// Handles jsonb returned as Map, String, or other formats to avoid type mismatch
  static Future<Map<String, dynamic>?> getPresetLayoutData(String presetId) async {
    try {
      final row = await _client
          .from('preset_layouts')
          .select('layout_data')
          .eq('id', presetId)
          .maybeSingle();
      if (row == null) return null;
      final data = row['layout_data'];
      if (data == null) return null;
      if (data is Map) return Map<String, dynamic>.from(data);
      if (data is String) {
        final decoded = jsonDecode(data);
        if (decoded is Map) return Map<String, dynamic>.from(decoded);
      }
      return null;
    } catch (e) {
      print('Error getPresetLayoutData: $e');
      return null;
    }
  }

  /// Save preset layout (update existing) - ใช้ RPC เฉพาะ staff ของร้าน
  /// หมายเหตุ: DB ใช้ฟังก์ชัน 2 params (p_layout_data, p_preset_id) ชื่อใส่ใน layout_data
  static Future<void> savePresetLayout(String presetId, Map<String, dynamic> layoutData) async {
    await _client.rpc(
      'update_preset_layout',
      params: {
        'p_preset_id': presetId,
        'p_layout_data': layoutData,
      },
    );
  }

  /// Create new preset layout - ใช้ RPC เฉพาะ staff ของร้าน
  static Future<String> createPresetLayout(
    String venueId, {
    String? name,
    required Map<String, dynamic> layoutData,
  }) async {
    final ld = Map<String, dynamic>.from(layoutData);
    if (name != null && name.isNotEmpty) ld['name'] = name;
    final result = await _client.rpc(
      'add_preset_layout',
      params: {
        'p_venue_id': venueId,
        'p_layout_data': ld,
        'p_name': name,
      },
    );
    return result as String;
  }

  /// Toggle table reservation status using RPC function
  /// Returns a Map with success status and updated data
  static Future<Map<String, dynamic>> toggleTableReservation({
    required String venueId,
    required String date,
    required String tableId,
    required String userId,
    required String floorId,
  }) async {
    try {
      final result = await _client.rpc(
        'toggle_table_reservation',
        params: {
          'p_venue_id': venueId,
          'p_date': date,
          'p_table_id': tableId,
          'p_user_id': userId,
          'p_floor_id': floorId,
        },
      );

      // RPC function returns JSON, convert to Map
      if (result is Map) {
        return Map<String, dynamic>.from(result);
      } else if (result is String) {
        // ถ้า return เป็น JSON string ให้ parse
        try {
          return jsonDecode(result) as Map<String, dynamic>;
        } catch (e) {
          print('⚠️ Failed to parse JSON string: $result');
          return {
            'success': false,
            'error': 'Failed to parse response',
          };
        }
      } else {
        return {
          'success': true,
          'result': result,
        };
      }
    } catch (e) {
      print('❌ Error in toggleTableReservation: $e');

      // Parse error message
      String errorMessage = 'Unknown error';
      if (e.toString().contains('Cannot toggle')) {
        errorMessage = 'Cannot toggle this table';
      } else if (e.toString().contains('not found')) {
        errorMessage = 'Layout or table not found';
      } else {
        errorMessage = e.toString();
      }

      throw Exception(errorMessage);
    }
  }
}

/// Transaction-like handle for batching Supabase reads/writes in one callback.
/// Each operation is a separate HTTP request; for true atomicity use a
/// PostgreSQL function and [SupabaseHelper.rpc].
class SupabaseTransaction {
  SupabaseTransaction(this._client);
  final SupabaseClient _client;

  /// Get a single document by table and id.
  Future<Map<String, dynamic>?> get(String table, String id) async {
    final res = await _client.from(table).select().eq('id', id).maybeSingle();
    return res;
  }

  /// Insert or upsert a document. If [data] contains 'id', uses upsert; otherwise insert.
  Future<Map<String, dynamic>> set(String table, Map<String, dynamic> data) async {
    final hasId = data.containsKey('id') && data['id'] != null;
    if (hasId) {
      final res = await _client.from(table).upsert(data).select().single();
      return res;
    }
    final res = await _client.from(table).insert(data).select().single();
    return res;
  }

  /// Update a document by id.
  Future<void> update(String table, String id, Map<String, dynamic> data) async {
    await _client.from(table).update(data).eq('id', id);
  }

  /// Delete a document by id.
  Future<void> delete(String table, String id) async {
    await _client.from(table).delete().eq('id', id);
  }
}
