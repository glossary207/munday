-- ========================================================================
-- RLS: staff_bills
--
-- แนวคิด:
-- - SELECT  → staff ของ venue + (owner หรือ bill.view = true)
-- - INSERT  → staff ของ venue (สร้างบิลตอน group / walk-in)
-- - UPDATE  → staff ของ venue (อัปเดตบิลได้ตามปกติ: เพิ่มรายการ, group/ungroup, checkout ฯลฯ)
-- - DELETE  → staff ของ venue (เช่น ungroup แล้วบิลไม่มีโต๊ะเหลือ)
-- การ void/refund จำกัดที่แอปหรือ RPC (เช็ค bill.void) — RLS แค่กันคนนอก venue
--
-- ใช้ helper is_staff_of_venue(venue_id) — ต้องรันสร้างฟังก์ชันก่อน (อยู่ใน venue_daily_layouts_rls.sql)
-- หรือรันบล็อกด้านล่างนี้ก่อนถ้ายังไม่มี
-- ========================================================================

-- ------------------------------------------------------------------------
-- Helper: ถ้ายังไม่มี is_staff_of_venue ให้รันบล็อกนี้ก่อน (ซ้ำกับ venue_daily_layouts_rls.sql)
-- ------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_staff_of_venue(p_venue_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM staff_venues sv
    JOIN staff_users su ON su.id = sv.staff_id
    WHERE sv.staff_id = auth.uid()
      AND sv.venue_id = p_venue_id
      AND COALESCE(sv.is_active, true) = true
      AND su.status = 'active'
  );
$$;

-- ------------------------------------------------------------------------
-- staff_bills
-- ------------------------------------------------------------------------

ALTER TABLE public.staff_bills ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "staff_bills_select_staff" ON public.staff_bills;
DROP POLICY IF EXISTS "staff_bills_insert_staff" ON public.staff_bills;
DROP POLICY IF EXISTS "staff_bills_update_staff" ON public.staff_bills;
DROP POLICY IF EXISTS "staff_bills_delete_staff" ON public.staff_bills;

-- SELECT: เฉพาะ staff ของ venue + มี bill.view หรือเป็น owner
CREATE POLICY "staff_bills_select_staff"
  ON public.staff_bills
  FOR SELECT
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
    AND EXISTS (
      SELECT 1
      FROM public.staff_venues sv
      WHERE sv.staff_id = auth.uid()
        AND sv.venue_id = staff_bills.venue_id
        AND COALESCE(sv.is_active, true) = true
        AND (
          sv.role = 'owner'
          OR COALESCE((sv.permissions->'bill'->>'view')::boolean, false)
        )
    )
  );

-- INSERT: staff ของ venue (สร้างบิลตอน group / walk-in)
CREATE POLICY "staff_bills_insert_staff"
  ON public.staff_bills
  FOR INSERT
  WITH CHECK (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
    AND created_by_staff_uuid = auth.uid()
  );

-- UPDATE: staff ของ venue (อัปเดตบิลได้ตามปกติ)
CREATE POLICY "staff_bills_update_staff"
  ON public.staff_bills
  FOR UPDATE
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  )
  WITH CHECK (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  );

-- DELETE: staff ของ venue (เช่น ungroup แล้วบิลไม่มีโต๊ะเหลือ)
CREATE POLICY "staff_bills_delete_staff"
  ON public.staff_bills
  FOR DELETE
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  );
