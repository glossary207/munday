-- ========================================================================
-- RLS: venue_daily_layouts + venue_daily_layout_floors + venue_daily_layout_tables
-- กลุ่ม Layout ทั้งชุด
--
-- แนวคิด:
-- - "ใครเห็น layout ได้"    → staff ของ venue + มี layout.view / edit_table_status / edit_layout หรือเป็น owner
-- - "ใครแก้ layout ได้"    → staff ของ venue + layout.edit_layout หรือเป็น owner
-- - "ใครแก้ status โต๊ะได้" → staff ของ venue + layout.edit_table_status / edit_layout หรือเป็น owner
-- - "ใครลบ layout/floor/table" → owner เท่านั้น (ลบโครง layout อันตราย)
--
-- ต้องมี helper is_staff_of_venue ก่อน (สร้างด้านล่างถ้ายังไม่มี)
-- ========================================================================

-- ------------------------------------------------------------------------
-- Helper: เช็คว่า auth.uid() เป็น staff ของ venue นี้หรือไม่
-- ------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.is_staff_of_venue(p_venue_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM staff_venues sv
    JOIN staff_users su ON su.id = sv.staff_id
    WHERE sv.staff_id = auth.uid()
      AND sv.venue_id = p_venue_id
      AND COALESCE(sv.is_active, true) = true
      AND su.status = 'active'
  );
$$;

COMMENT ON FUNCTION public.is_staff_of_venue(uuid) IS
  'Returns true if current user (auth.uid()) is active staff of the given venue.';

-- ------------------------------------------------------------------------
-- venue_daily_layouts
-- ------------------------------------------------------------------------

ALTER TABLE public.venue_daily_layouts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "venue_daily_layouts_select_staff" ON public.venue_daily_layouts;
DROP POLICY IF EXISTS "venue_daily_layouts_insert_staff" ON public.venue_daily_layouts;
DROP POLICY IF EXISTS "venue_daily_layouts_update_staff" ON public.venue_daily_layouts;
DROP POLICY IF EXISTS "venue_daily_layouts_delete_owner" ON public.venue_daily_layouts;

-- เห็น layout ได้ = เป็น staff ของ venue + มี layout permission ใดก็ได้ หรือเป็น owner
CREATE POLICY "venue_daily_layouts_select_staff"
  ON public.venue_daily_layouts
  FOR SELECT
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
    AND EXISTS (
      SELECT 1
      FROM public.staff_venues sv
      WHERE sv.staff_id = auth.uid()
        AND sv.venue_id = venue_daily_layouts.venue_id
        AND COALESCE(sv.is_active, true) = true
        AND (
          sv.role = 'owner'
          OR COALESCE((sv.permissions->'layout'->>'view')::boolean, false)
          OR COALESCE((sv.permissions->'layout'->>'edit_table_status')::boolean, false)
          OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
        )
    )
  );

-- สร้าง / แก้ layout ทั้งก้อน → ต้องเป็น staff + มีสิทธิ์ edit_layout หรือ owner
CREATE POLICY "venue_daily_layouts_insert_staff"
  ON public.venue_daily_layouts
  FOR INSERT
  WITH CHECK (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
    AND EXISTS (
      SELECT 1
      FROM public.staff_venues sv
      WHERE sv.staff_id = auth.uid()
        AND sv.venue_id = venue_daily_layouts.venue_id
        AND COALESCE(sv.is_active, true) = true
        AND (
          sv.role = 'owner'
          OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
        )
    )
  );

CREATE POLICY "venue_daily_layouts_update_staff"
  ON public.venue_daily_layouts
  FOR UPDATE
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
    AND EXISTS (
      SELECT 1
      FROM public.staff_venues sv
      WHERE sv.staff_id = auth.uid()
        AND sv.venue_id = venue_daily_layouts.venue_id
        AND COALESCE(sv.is_active, true) = true
        AND (
          sv.role = 'owner'
          OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
        )
    )
  )
  WITH CHECK (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
    AND EXISTS (
      SELECT 1
      FROM public.staff_venues sv
      WHERE sv.staff_id = auth.uid()
        AND sv.venue_id = venue_daily_layouts.venue_id
        AND COALESCE(sv.is_active, true) = true
        AND (
          sv.role = 'owner'
          OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
        )
    )
  );

-- ลบ layout ทั้งก้อน → owner เท่านั้น
CREATE POLICY "venue_daily_layouts_delete_owner"
  ON public.venue_daily_layouts
  FOR DELETE
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
    AND EXISTS (
      SELECT 1
      FROM public.staff_venues sv
      WHERE sv.staff_id = auth.uid()
        AND sv.venue_id = venue_daily_layouts.venue_id
        AND COALESCE(sv.is_active, true) = true
        AND sv.role = 'owner'
    )
  );


-- ------------------------------------------------------------------------
-- venue_daily_layout_floors
-- ------------------------------------------------------------------------

ALTER TABLE public.venue_daily_layout_floors ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "venue_daily_layout_floors_select_staff" ON public.venue_daily_layout_floors;
DROP POLICY IF EXISTS "venue_daily_layout_floors_insert_staff" ON public.venue_daily_layout_floors;
DROP POLICY IF EXISTS "venue_daily_layout_floors_update_staff" ON public.venue_daily_layout_floors;
DROP POLICY IF EXISTS "venue_daily_layout_floors_delete_owner" ON public.venue_daily_layout_floors;

-- SELECT floors: เดินตาม layout → venue_id แล้วใช้เงื่อนไขเดียวกับ select layout
CREATE POLICY "venue_daily_layout_floors_select_staff"
  ON public.venue_daily_layout_floors
  FOR SELECT
  USING (
    venue_daily_layout_id IN (
      SELECT vdl.id
      FROM public.venue_daily_layouts vdl
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'view')::boolean, false)
              OR COALESCE((sv.permissions->'layout'->>'edit_table_status')::boolean, false)
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  );

-- INSERT / UPDATE floors → ต้องมีสิทธิ์ edit_layout หรือ owner
CREATE POLICY "venue_daily_layout_floors_insert_staff"
  ON public.venue_daily_layout_floors
  FOR INSERT
  WITH CHECK (
    venue_daily_layout_id IN (
      SELECT vdl.id
      FROM public.venue_daily_layouts vdl
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  );

CREATE POLICY "venue_daily_layout_floors_update_staff"
  ON public.venue_daily_layout_floors
  FOR UPDATE
  USING (
    venue_daily_layout_id IN (
      SELECT vdl.id
      FROM public.venue_daily_layouts vdl
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  )
  WITH CHECK (
    venue_daily_layout_id IN (
      SELECT vdl.id
      FROM public.venue_daily_layouts vdl
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  );

-- ลบชั้น → owner เท่านั้น
CREATE POLICY "venue_daily_layout_floors_delete_owner"
  ON public.venue_daily_layout_floors
  FOR DELETE
  USING (
    venue_daily_layout_id IN (
      SELECT vdl.id
      FROM public.venue_daily_layouts vdl
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND sv.role = 'owner'
        )
    )
  );


-- ------------------------------------------------------------------------
-- venue_daily_layout_tables
-- ------------------------------------------------------------------------

ALTER TABLE public.venue_daily_layout_tables ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "venue_daily_layout_tables_select_staff" ON public.venue_daily_layout_tables;
DROP POLICY IF EXISTS "venue_daily_layout_tables_insert_staff" ON public.venue_daily_layout_tables;
DROP POLICY IF EXISTS "venue_daily_layout_tables_update_staff" ON public.venue_daily_layout_tables;
DROP POLICY IF EXISTS "venue_daily_layout_tables_delete_owner" ON public.venue_daily_layout_tables;

-- SELECT tables → staff + layout.view / edit_table_status / edit_layout หรือ owner
CREATE POLICY "venue_daily_layout_tables_select_staff"
  ON public.venue_daily_layout_tables
  FOR SELECT
  USING (
    venue_daily_layout_floor_id IN (
      SELECT f.id
      FROM public.venue_daily_layout_floors f
      JOIN public.venue_daily_layouts vdl ON vdl.id = f.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'view')::boolean, false)
              OR COALESCE((sv.permissions->'layout'->>'edit_table_status')::boolean, false)
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  );

-- INSERT tables → สร้างโต๊ะ/โครง layout → ต้องมี edit_layout หรือ owner
CREATE POLICY "venue_daily_layout_tables_insert_staff"
  ON public.venue_daily_layout_tables
  FOR INSERT
  WITH CHECK (
    venue_daily_layout_floor_id IN (
      SELECT f.id
      FROM public.venue_daily_layout_floors f
      JOIN public.venue_daily_layouts vdl ON vdl.id = f.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  );

-- UPDATE tables → ใช้ทั้งตอนเปลี่ยน status และตอนแก้ layout
-- เงื่อนไข: staff + (edit_table_status หรือ edit_layout หรือ owner)
CREATE POLICY "venue_daily_layout_tables_update_staff"
  ON public.venue_daily_layout_tables
  FOR UPDATE
  USING (
    venue_daily_layout_floor_id IN (
      SELECT f.id
      FROM public.venue_daily_layout_floors f
      JOIN public.venue_daily_layouts vdl ON vdl.id = f.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'edit_table_status')::boolean, false)
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  )
  WITH CHECK (
    venue_daily_layout_floor_id IN (
      SELECT f.id
      FROM public.venue_daily_layout_floors f
      JOIN public.venue_daily_layouts vdl ON vdl.id = f.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND (
              sv.role = 'owner'
              OR COALESCE((sv.permissions->'layout'->>'edit_table_status')::boolean, false)
              OR COALESCE((sv.permissions->'layout'->>'edit_layout')::boolean, false)
            )
        )
    )
  );

-- DELETE tables → ลบโต๊ะออกจาก layout → จำกัด owner เท่านั้น
CREATE POLICY "venue_daily_layout_tables_delete_owner"
  ON public.venue_daily_layout_tables
  FOR DELETE
  USING (
    venue_daily_layout_floor_id IN (
      SELECT f.id
      FROM public.venue_daily_layout_floors f
      JOIN public.venue_daily_layouts vdl ON vdl.id = f.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL
        AND is_staff_of_venue(vdl.venue_id)
        AND EXISTS (
          SELECT 1
          FROM public.staff_venues sv
          WHERE sv.staff_id = auth.uid()
            AND sv.venue_id = vdl.venue_id
            AND COALESCE(sv.is_active, true) = true
            AND sv.role = 'owner'
        )
    )
  );

-- RLS: venue_daily_layouts + floors + tables (กลุ่ม layout ทั้งชุด)
-- สิทธิ์พื้นฐาน: staff ของ venue นั้นเท่านั้น (เช็คผ่าน is_staff_of_venue)
-- ถ้าอยากผูกกับ JSON permissions (layout.view / edit_table_status / edit_layout)
-- ค่อยเติมเงื่อนไขเพิ่มใน USING / WITH CHECK ภายหลังได้

-- ---------------------------------------------------------------------------
-- venue_daily_layouts
-- ---------------------------------------------------------------------------

ALTER TABLE public.venue_daily_layouts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "venue_daily_layouts_select_staff" ON public.venue_daily_layouts;
DROP POLICY IF EXISTS "venue_daily_layouts_insert_staff" ON public.venue_daily_layouts;
DROP POLICY IF EXISTS "venue_daily_layouts_update_staff" ON public.venue_daily_layouts;
DROP POLICY IF EXISTS "venue_daily_layouts_delete_staff" ON public.venue_daily_layouts;

CREATE POLICY "venue_daily_layouts_select_staff"
  ON public.venue_daily_layouts
  FOR SELECT
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  );

CREATE POLICY "venue_daily_layouts_insert_staff"
  ON public.venue_daily_layouts
  FOR INSERT
  WITH CHECK (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  );

CREATE POLICY "venue_daily_layouts_update_staff"
  ON public.venue_daily_layouts
  FOR UPDATE
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  )
  WITH CHECK (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  );

CREATE POLICY "venue_daily_layouts_delete_staff"
  ON public.venue_daily_layouts
  FOR DELETE
  USING (
    venue_id IS NOT NULL
    AND is_staff_of_venue(venue_id)
  );

-- ---------------------------------------------------------------------------
-- venue_daily_layout_floors
-- ---------------------------------------------------------------------------

ALTER TABLE public.venue_daily_layout_floors ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "venue_daily_layout_floors_select_staff" ON public.venue_daily_layout_floors;
DROP POLICY IF EXISTS "venue_daily_layout_floors_insert_staff" ON public.venue_daily_layout_floors;
DROP POLICY IF EXISTS "venue_daily_layout_floors_update_staff" ON public.venue_daily_layout_floors;
DROP POLICY IF EXISTS "venue_daily_layout_floors_delete_staff" ON public.venue_daily_layout_floors;

CREATE POLICY "venue_daily_layout_floors_select_staff"
  ON public.venue_daily_layout_floors
  FOR SELECT
  USING (
    venue_daily_layout_id IN (
      SELECT id FROM venue_daily_layouts
      WHERE venue_id IS NOT NULL AND is_staff_of_venue(venue_id)
    )
  );

CREATE POLICY "venue_daily_layout_floors_insert_staff"
  ON public.venue_daily_layout_floors
  FOR INSERT
  WITH CHECK (
    venue_daily_layout_id IN (
      SELECT id FROM venue_daily_layouts
      WHERE venue_id IS NOT NULL AND is_staff_of_venue(venue_id)
    )
  );

CREATE POLICY "venue_daily_layout_floors_update_staff"
  ON public.venue_daily_layout_floors
  FOR UPDATE
  USING (
    venue_daily_layout_id IN (
      SELECT id FROM venue_daily_layouts
      WHERE venue_id IS NOT NULL AND is_staff_of_venue(venue_id)
    )
  )
  WITH CHECK (
    venue_daily_layout_id IN (
      SELECT id FROM venue_daily_layouts
      WHERE venue_id IS NOT NULL AND is_staff_of_venue(venue_id)
    )
  );

CREATE POLICY "venue_daily_layout_floors_delete_staff"
  ON public.venue_daily_layout_floors
  FOR DELETE
  USING (
    venue_daily_layout_id IN (
      SELECT id FROM venue_daily_layouts
      WHERE venue_id IS NOT NULL AND is_staff_of_venue(venue_id)
    )
  );

-- ---------------------------------------------------------------------------
-- venue_daily_layout_tables
-- ---------------------------------------------------------------------------

ALTER TABLE public.venue_daily_layout_tables ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "venue_daily_layout_tables_select_staff" ON public.venue_daily_layout_tables;
DROP POLICY IF EXISTS "venue_daily_layout_tables_insert_staff" ON public.venue_daily_layout_tables;
DROP POLICY IF EXISTS "venue_daily_layout_tables_update_staff" ON public.venue_daily_layout_tables;
DROP POLICY IF EXISTS "venue_daily_layout_tables_delete_staff" ON public.venue_daily_layout_tables;

CREATE POLICY "venue_daily_layout_tables_select_staff"
  ON public.venue_daily_layout_tables
  FOR SELECT
  USING (
    venue_daily_layout_floor_id IN (
      SELECT vdlf.id
      FROM venue_daily_layout_floors vdlf
      JOIN venue_daily_layouts vdl ON vdl.id = vdlf.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL AND is_staff_of_venue(vdl.venue_id)
    )
  );

CREATE POLICY "venue_daily_layout_tables_insert_staff"
  ON public.venue_daily_layout_tables
  FOR INSERT
  WITH CHECK (
    venue_daily_layout_floor_id IN (
      SELECT vdlf.id
      FROM venue_daily_layout_floors vdlf
      JOIN venue_daily_layouts vdl ON vdl.id = vdlf.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL AND is_staff_of_venue(vdl.venue_id)
    )
  );

CREATE POLICY "venue_daily_layout_tables_update_staff"
  ON public.venue_daily_layout_tables
  FOR UPDATE
  USING (
    venue_daily_layout_floor_id IN (
      SELECT vdlf.id
      FROM venue_daily_layout_floors vdlf
      JOIN venue_daily_layouts vdl ON vdl.id = vdlf.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL AND is_staff_of_venue(vdl.venue_id)
    )
  )
  WITH CHECK (
    venue_daily_layout_floor_id IN (
      SELECT vdlf.id
      FROM venue_daily_layout_floors vdlf
      JOIN venue_daily_layouts vdl ON vdl.id = vdlf.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL AND is_staff_of_venue(vdl.venue_id)
    )
  );

CREATE POLICY "venue_daily_layout_tables_delete_staff"
  ON public.venue_daily_layout_tables
  FOR DELETE
  USING (
    venue_daily_layout_floor_id IN (
      SELECT vdlf.id
      FROM venue_daily_layout_floors vdlf
      JOIN venue_daily_layouts vdl ON vdl.id = vdlf.venue_daily_layout_id
      WHERE vdl.venue_id IS NOT NULL AND is_staff_of_venue(vdl.venue_id)
    )
  );

